<?php
class IndexController extends \HXPHP\System\Controller
{

}